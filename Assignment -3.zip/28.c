#include <stdio.h>
int main() {
    int n,sum=0;
    scanf("%d",&n);
    if(n<=0) return 0;
    for(int i=1;i<=n/2;i++) if(n%i==0) sum+=i;
    if(sum==n) printf("Perfect");
    else printf("Not Perfect");
    return 0;
}