#include <stdio.h>
int main() {
    char name[] = "YourName";
    for (int i = 0; i < 5; i++)
        printf("%s\n", name);
    return 0;
}